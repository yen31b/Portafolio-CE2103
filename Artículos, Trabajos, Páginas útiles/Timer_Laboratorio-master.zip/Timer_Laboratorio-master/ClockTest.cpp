#include "ClockTest.h"

void ClockTest::generalClockTest()
{

    MyClock clock(new Counter);


    QDate currentDate=QDate::currentDate();


    QString form="dd-mm-yyyy";
    (clock.MyCounter)->setDateFormat(form);

    clock.refresh();

    QString date=clock.getStrDate();

    std::string day=std::to_string(currentDate.day());
    std::string month=std::to_string(currentDate.month());
    std::string year=std::to_string(currentDate.year());


    std::string left=date.toStdString();
    std::string confront=day+'-'+'0'+month+'-'+year;

    QVERIFY(left==confront);

    QTime currentTime=QTime::currentTime();

    form="hh:mm";
    (clock.MyCounter)->setTimeFormat(form);
    clock.refresh();
    QString time=clock.getStrTime();

    std::string hou=std::to_string(currentTime.hour());
    std::string min=std::to_string(currentTime.minute());
    std::string sec=std::to_string(currentTime.second());

    if(currentTime.minute()<10)
        min='0'+min;
    if(currentTime.second()<10)
        sec='0'+sec;
    if(currentTime.hour()<10)
        hou='0'+hou;

    left=time.toStdString();
    confront=hou+':'+min;

    QVERIFY(left==confront);


}
