#ifndef CLOCKTEST_H
#define CLOCKTEST_H

#include "QTest"
#include "MyClock.h"
#include "Counter.h"
class ClockTest:public QObject
{
    Q_OBJECT



private slots:
    void generalClockTest();
};

#endif // CLOCKTEST_H
