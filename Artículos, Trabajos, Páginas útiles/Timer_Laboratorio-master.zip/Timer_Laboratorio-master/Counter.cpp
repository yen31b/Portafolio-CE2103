#include "Counter.h"

Counter::Counter()
{
date=Date();
time=Time();
QTimer* timer=new QTimer(this);
connect(timer, SIGNAL(timeout()), this, SLOT(increase()));
timer->start(1000);
increase();
}

void Counter::increase(){
    if(time.getSec()<59)
        time.setSec(time.getSec()+1);
    else{
        time.setSec(0);
        if(time.getMin()<59)
            time.setMin(time.getMin()+1);
        else{
            time.setMin(0);
            if(time.getHou()<23)
                time.setHou(time.getHou()+1);
            else{
                time.setHou(0);
                date.setDay(date.getDay()+1);
            }
        }
    }
update();
}


void Counter::update(){
    for(auto itr=observers.begin();itr!=observers.end();itr++)
       (*itr)->refresh();
}

void Counter::subscribe(Observer* o){
    observers.push_back(o);
}

void Counter::unsubscribe(Observer* o){
    observers.remove(o);
}

Time& Counter::getRightTime(){
    return time;
}

Date& Counter::getRightDate(){
    return date;
}

Counter& Counter::getCounter(){
    return *this;
}

void Counter::setDateFormat(QString &form){
    date.setFormat(form);
}

void Counter::setTimeFormat(QString &form){
    time.setFormat(form);
}


std::string& Counter::getStringTime(){
    return time.getSHM();
}

std::string& Counter::getStringDate(){

    std::string day=std::to_string(date.getDay());
    if(date.getDay()<10)
        day='0'+std::to_string(date.getDay());
    std::string mon=std::to_string(date.getMonth());
    if(date.getMonth()<10)
    mon='0'+std::to_string(date.getMonth());

    if(date.getFormat()=="day-month-year")
        strdate=date.getdayOf()+' '+day+' '+date.getmonthOf()+' '+std::to_string(date.getYear());
    if(date.getFormat()=="dd-mm-yyyy")
        strdate=day+'-'+mon+'-'+std::to_string(date.getYear());
    if(date.getFormat()=="mm-dd-yyyy")
        strdate=mon+'-'+day+'-'+std::to_string(date.getYear());


   return strdate;
}
