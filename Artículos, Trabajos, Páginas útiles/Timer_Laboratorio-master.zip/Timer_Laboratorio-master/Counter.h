#ifndef COUNTER_H
#define COUNTER_H


#include <QTimer>
#include "Time.h"
#include "Date.h"
#include <list>
#include "observer.h"
#include "QObject"
class Counter:public QObject
{
    Q_OBJECT
public:

    Counter();

    void update();
    void subscribe(Observer* o);
    void unsubscribe(Observer* o);
    Time& getRightTime();
    Date& getRightDate();
    Counter& getCounter();

    void setDateFormat(QString& form);
    void setTimeFormat(QString& form);

    std::string& getStringTime();
    std::string& getStringDate();

    ~Counter(){
        for(auto itr=observers.begin();itr!=observers.end();itr++)
            unsubscribe(*itr);
    }


private:
    Date date;
    Time time;
    std::list<Observer*>observers;
    std::string strtime;
    std::string strdate;
public slots:
    void increase();

};

#endif // COUNTER_H
