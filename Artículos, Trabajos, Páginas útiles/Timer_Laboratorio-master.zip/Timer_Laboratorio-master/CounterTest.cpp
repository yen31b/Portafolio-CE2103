#include "CounterTest.h"

void CounterTest::generalCounterTest(){
    if(QTime::currentTime().second()!=59)
        QVERIFY(counter.getRightTime().getSec()==QTime::currentTime().second()+1);
    else{
        QVERIFY(counter.getRightTime().getMin()==QTime::currentTime().minute()+1);
    }
    //con quel +1 viene già testata la funzione increase

    counter.getRightDate().setDate(5,8,2015);
    QString form="dd-mm-yyyy";
    counter.setDateFormat(form);
    QVERIFY(counter.getStringDate()=="05-08-2015");

    form="mm-dd-yyyy";
    counter.setDateFormat(form);
    QVERIFY(counter.getStringDate()=="08-05-2015");

}
