#ifndef COUNTERTEST_H
#define COUNTERTEST_H

#include "QtTest"
#include "Counter.h"

class CounterTest:public QObject
{
    Q_OBJECT
private:
    Counter counter;

private slots:
void generalCounterTest();

};

#endif // COUNTERTEST_H
