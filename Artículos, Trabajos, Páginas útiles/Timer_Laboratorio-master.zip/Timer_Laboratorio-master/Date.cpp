#include "Date.h"
                
Date::Date()
{
QDate current=QDate::currentDate();
day=current.day();
month=current.month();
year=current.year();
dayOf=current.dayOfWeek();
LeapYear=current.isLeapYear(year);
controlMonthOf();
controlDayOf();
}

void Date::controlDayOf(){

    switch(dayOf){
    case(1):strdayOf="lunedi'";
        break;
    case(2):strdayOf="martedi'";
        break;
    case(3):strdayOf="mercoledi'";
        break;
    case(4):strdayOf="giovedi'";
        break;
    case(5):strdayOf="venerdi'";
        break;
    case(6):strdayOf="sabato";
        break;
    case(7):strdayOf="domenica";
         break;
           
    }
}

bool Date::getLeap(){
    return LeapYear;
}


void Date::controlMonthOf(){
    switch(month){
    case(1):monthOf="gennaio";
        break;
    case(2):monthOf="febbraio";
        break;
    case(3):monthOf="marzo";
        break;
    case(4):monthOf="aprile";
        break;
    case(5):monthOf="maggio";
        break;
    case(6):monthOf="giugno";
        break;
    case(7):monthOf="luglio";
        break;
    case(8):monthOf="agosto";
        break;
    case(9):monthOf="settembre";
        break;
    case(10):monthOf="ottobre";
        break;
    case(11):monthOf="novembre";
        break;
    case(12):monthOf="dicembre";
        
    }
}

void Date::setDate(int d, int m, int y){
    if(y>=0)
        year=y;
    else
        year=QDate::currentDate().year();

    LeapYear=controlLeap(year);
    if(m<0 || m>12)
        month=QDate::currentDate().month();
    else
        month=m;
    if(d<0 || d>31)
        day=QDate::currentDate().day();
    else
        day=d;

    if((month==4 || month==6 ||month==9 || month==11)&& d==31)
            day=QDate::currentDate().day();
    if(month==2 && LeapYear==false && d>=29)
        day=QDate::currentDate().day();


    controlMonthOf();
    controlDayOf();

}

void Date::setDay(int d){
    if((d<=30 && month!=2) || d<=28 ||(d==29 && LeapYear==true)||(d==31 && (month!=4 &&  month!= 6 &&
                                                                            month!=9 && month!= 11 &&
                                                                            month!=2)))
        day=d;
    else{
        day=1;
        month=month+1;
        }
    if(month>12){
        month=1;
        year=year+1;
        controlMonthOf();
        controlDayOf();
    }
   }


bool Date::controlLeap(int year){
    if((year%4==0 && year%100 && year%400) || (year%4==0 && year%100!=0))
        return true;
    else
        return false;

}

Date& Date::getDate(){
    return *this;
}

int Date::getDay(){
    return day;
}

int Date::getMonth(){
    return month;
}

int Date::getYear(){
    return year;}


void Date::setLeapYar(bool leap){
    LeapYear=leap;
}

void Date::setFormat(QString format){
    dateFormat=format;
}

QString& Date::getFormat(){
    return dateFormat;
}

std::string& Date::getmonthOf(){
    return monthOf;
}

std::string& Date::getdayOf(){
    return strdayOf;
}
