#ifndef DATE_H
#define DATE_H

#include <QDate>

class Date
{

public:
    Date();

    void setDate(int d, int m, int y);
    void setLeapYar(bool leap);
    void setFormat(QString format);
    void setDay(int d);

    Date& getDate();
    int getDay();
    int getMonth();
    int getYear();
    std::string& getmonthOf();
    std::string& getdayOf();
    bool getLeap();
    
    QString& getFormat();

    bool controlLeap(int year);

    void controlMonthOf();
    void controlDayOf();



private:
    int day,month,year,dayOf;
    std::string monthOf,strdayOf;
    QString dateFormat;
    bool LeapYear;
};

#endif // DATE_H
