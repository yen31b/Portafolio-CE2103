#include "DateTest.h"

void DateTest::dateConstructorTest(){
    QCOMPARE(date.getDay(),QDate::currentDate().day());
    QCOMPARE(date.getMonth(),QDate::currentDate().month());
    QCOMPARE(date.getYear(),QDate::currentDate().year());


}

void DateTest::setDateTest(){

    date.setDate(5,10,2014);

    QVERIFY(date.getDay()==5);
    QVERIFY(date.getMonth()==10);
    QVERIFY(date.getYear()==2014);
    QVERIFY(date.getLeap()==false); //2014 non era bisestile
    QVERIFY(date.getmonthOf()=="ottobre");

    date.setDate(29,2,2016);
    QVERIFY(date.getDay()==29);
    QVERIFY(date.getMonth()==2);

    date.setDate(31,1,2014);
    QVERIFY(date.getDay()==31);


}

void DateTest::setWrong(){

    date.setDate(29,2,2014);
    QVERIFY(date.getDay()==QDate::currentDate().day());
    QVERIFY(date.getMonth()==2);


    date.setDate(35,5,2016);
    QVERIFY(date.getDay()==QDate::currentDate().day());
    QVERIFY(date.getMonth()==5);

    date.setDate(10,20,-4);
    QVERIFY(date.getMonth()==QDate::currentDate().month());
    QVERIFY(date.getYear()==QDate::currentDate().year());

}
