#ifndef DATETEST_H
#define DATETEST_H

#include "QTest"
#include "Date.h"
class DateTest: public QObject
{
    Q_OBJECT

private:
    Date date;

private slots:
    void dateConstructorTest();
    void setDateTest();
    void setWrong();




};

#endif // DATETEST_H
