#include "DisplayTest.h"
#include "QTimeEdit"
#include "Counter.h"


void DisplayTest::generalDisplayTest(){


    TimerDisplay display(new QTimeEdit,new Counter);

    Time time=display.getThisTime();
    QVERIFY(time.getHou()==0);
    QVERIFY(time.getMin()==0);
    QVERIFY(time.getSec()==0);

    QTime tempo(5,14,0);
    display.getEDitor()->setTime(tempo);
    display.updateEditor();

    time=display.getThisTime();
    QVERIFY(time.getHou()==5);
    QVERIFY(time.getMin()==14);
    QVERIFY(time.getSec()==0);
    
   display.getEDitor()->setTime(tempo);
   display.fromStart();
   display.refresh();

    time=display.getThisTime();
    QVERIFY(time.getHou()==5);
    QVERIFY(time.getMin()==13);
    QVERIFY(time.getSec()==59);
    
    
    display.fromReset();
    time=display.getThisTime();
    QVERIFY(time.getHou()==0);
    QVERIFY(time.getMin()==0);
    QVERIFY(time.getSec()==0);
    
    display.fromStart();
    display.refresh();
    QVERIFY(display.isTimeOut()==true);

    


}



