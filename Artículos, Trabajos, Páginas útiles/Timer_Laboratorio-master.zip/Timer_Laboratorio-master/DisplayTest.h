#ifndef DISPLAYTEST_H
#define DISPLAYTEST_H

#include "QtTest"
#include "TimerDisplay.h"

class DisplayTest:public QObject
{
    Q_OBJECT



private slots:
    void generalDisplayTest();


};

#endif // DISPLAYTEST_H
