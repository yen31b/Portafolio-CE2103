//
// Created by Fra on 22/08/2016.
//

#include "MyClock.h"
#include "QTimer"

MyClock::MyClock(Counter* counter,QWidget* parent){

    date.setGeometry(210,20,261,41);
    time.setGeometry(475,0,121,80);

    date.setParent(parent);
    time.setParent(parent);
    date.setAlignment(Qt::AlignCenter);
    time.setAlignment(Qt::AlignCenter);

    QFont DataTimeFont;
    DataTimeFont=time.font();
    DataTimeFont.setPointSize(14);

    DataTimeFont=date.font();
    DataTimeFont.setPointSize(14);

    SelectDateFormat.setParent(parent);
    SelectDateFormat.setGeometry(20,10,160,33);


    SelectDateFormat.addItem("day-month-year");
    SelectDateFormat.addItem("dd-mm-yyyy");
    SelectDateFormat.addItem("yyyy-mm-dd");

    SelectTimeFormat.setParent(parent);
    SelectTimeFormat.setGeometry(20,40,160,33);

    SelectTimeFormat.addItem("hh:mm:ss");
    SelectTimeFormat.addItem("hh:mm");
    MyCounter=counter;
    attach();


}

void MyClock::attach(){
    MyCounter->subscribe(this);

}

void MyClock::refresh(){
    time.setText(QString::fromStdString(MyCounter->getStringTime()));
    date.setText(QString::fromStdString(MyCounter->getStringDate()));

    QString form;
    switch(SelectTimeFormat.currentIndex()){
    case(0):form="hh:mm:ss";

        break;
    case(1):
        form="hh:mm";

        break;
    default:form="hh:mm:ss";
    }
    MyCounter->setTimeFormat(form);

    switch(SelectDateFormat.currentIndex()){
    case(0):form="day-month-year";
        break;
    case(1):form="dd-mm-yyyy";
        break;
    case(2):form="mm-dd-yyyy";
        break;
    default: form="day-month-year";
    }
    MyCounter->setDateFormat(form);
}

void MyClock::detach(){
    MyCounter->unsubscribe(this);
}

void MyClock::changeFormat(){
    QString form=SelectTimeFormat.currentText();
    MyCounter->setTimeFormat(form);
}

QString MyClock::getStrTime(){
    return time.text();
}

QString MyClock::getStrDate(){
    return date.text();
}
