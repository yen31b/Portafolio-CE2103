//
// Created by Fra on 22/08/2016.
//

#ifndef TIMERSCANDIFFIO_MYCLOCK_H
#define TIMERSCANDIFFIO_MYCLOCK_H

#include "QTimeEdit"
#include "QLabel"
#include "QTime"
#include "QObject"
#include "QComboBox"
#include "observer.h"
#include "Counter.h"

class MyClock : public QObject, public Observer
{
//macro di Qt che fornisce alla classe la possibilità di avere signals and slots
Q_OBJECT

public:

     MyClock(Counter* counter,QWidget* parent=nullptr);
    //virtual ~MyClock() Il rilascio delle risorse è gestito dalla classe Base



    virtual void attach()override;
    virtual void detach()override;
    virtual void refresh()override;

    //le seguenti funzioni pubbliche servono solo per i test
    QString getStrTime();
    QString getStrDate();

    Counter* MyCounter;
private:
    QComboBox SelectDateFormat;
    QComboBox SelectTimeFormat;
    QLabel date;
    QLabel time;


private slots:
    void changeFormat();


};

#endif //TIMERSCANDIFFIO_MYCLOCK_H
