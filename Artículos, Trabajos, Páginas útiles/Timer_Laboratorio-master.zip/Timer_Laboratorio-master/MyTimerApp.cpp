//
// Created by Fra on 23/08/2016.
//
#include "MyTimerApp.h"
#include "ui_MyTimerApp.h"

MyTimerApp::MyTimerApp(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MyTimerApp)
{
    ui->setupUi(this);

}

MyTimerApp::~MyTimerApp()
{
    delete ui;
}


