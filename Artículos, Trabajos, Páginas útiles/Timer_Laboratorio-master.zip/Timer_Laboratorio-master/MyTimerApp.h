//
// Created by Fra on 23/08/2016.
//

#ifndef TIMER_SCANDIFFIO_MYTIMERAPP_H
#define TIMER_SCANDIFFIO_MYTIMERAPP_H

#include "QWidget"

namespace  Ui {
    class MyTimerApp;
}

class MyTimerApp: public QWidget{
    Q_OBJECT

public:
    explicit MyTimerApp(QWidget* parent=0);
    ~MyTimerApp();

private:
    Ui::MyTimerApp* ui;
};

#endif //TIMER_SCANDIFFIO_MYTIMERAPP_H
