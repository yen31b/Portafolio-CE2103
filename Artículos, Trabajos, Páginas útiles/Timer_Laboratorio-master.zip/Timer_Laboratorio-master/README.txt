# Timer_Laboratorio
Per la realizzazione di questo progetto ho utilizzato le librerie di Qt5

Progetto completo di classi e test aggiornato al 20/9/16
    
    
