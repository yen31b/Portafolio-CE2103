#include "Time.h"
#include "QTime"

Time::Time()
{
QTime current=QTime::currentTime();
second=current.second();
hour=current.hour();
minute=current.minute();
}


void Time::setTime(int s,int m,int h){
    if(h<0 || h>23)
        hour=QTime::currentTime().hour();
    else
        hour=h;
    if(m<0 || m>59)
        minute=QTime::currentTime().minute();
    else
        minute=m;
    if(s<0 || s>59)
        second=QTime::currentTime().second();
    else
        second=s;

}

std::string& Time::getSHM(){

    std::string sec=std::to_string(second);
    if(second<10)
    sec='0'+std::to_string(second);

    std::string min=std::to_string(minute);
    if(minute<10)
        min='0'+std::to_string(minute);

    std::string hou=std::to_string(hour);
    if(hour<10)
        hou='0'+std::to_string(hour);

    if(TimeFormat=="hh:mm:ss")
    SHM=hou+':'+min+':'+sec;

    if(getFormat()=="hh:mm")
        SHM=hou+':'+min;

    return SHM;
}


void Time::setSec(int s){
    if(s<0 || s>59)
    second=QTime::currentTime().second();
else
    second=s;

}

void Time::setMin(int m){
    if(m<0 || m>59)
        minute=QTime::currentTime().minute();
    else
        minute=m;
}

void Time::setHou(int h){
    if(h<0 || h>23)
        hour=QTime::currentTime().hour();
    else
        hour=h;
}

void Time::setFormat(QString& format){
    TimeFormat=format;
}

int Time::getSec(){
    return second;
}

int Time::getMin(){
    return minute;
}

int Time::getHou(){
    return hour;
}

QString& Time::getFormat(){
    return TimeFormat;
}

Time& Time::getTime(){
    return *this;
}
