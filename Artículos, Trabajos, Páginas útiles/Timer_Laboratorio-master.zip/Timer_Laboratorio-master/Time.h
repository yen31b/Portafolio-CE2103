#ifndef TIME_H
#define TIME_H

#include <QString>
class Time
{
public:

    Time();
    void setTime(int s,int m, int h);


    void setSec(int s);
    void setMin(int m);
    void setHou(int h);
    void setFormat(QString& format);

    int getSec();
    int getMin();
    int getHou();
    QString& getFormat();
    std::string& getSHM();

    Time& getTime();


private:
    int second,minute,hour;
    QString TimeFormat;
    std::string SHM;
};

#endif // TIME_H
