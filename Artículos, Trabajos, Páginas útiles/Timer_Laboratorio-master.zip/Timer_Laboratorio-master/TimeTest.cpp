#include "TimeTest.h"

void TimeTest::timeConstructorTest(){
    QCOMPARE(time.getHou(),QTime::currentTime().hour());
    QCOMPARE(time.getMin(),QTime::currentTime().minute());
    QCOMPARE(time.getSec(),QTime::currentTime().second());

}


void TimeTest::setGetTimeTest(){

    time.setTime(40,23,15);
    QVERIFY(time.getSec()==40);
    QVERIFY(time.getMin()==23);
    QVERIFY(time.getHou()==15);

}

void TimeTest::controlFormat(){
    QString format=QString::fromStdString("hh:mm");
    time.setFormat(format);
    std::string result;
    result=std::to_string(time.getHou())+':'+std::to_string(time.getMin());

    QVERIFY(time.getSHM()==result);


}

void TimeTest::setWrongTime(){

   time.setTime(70,-14,100);
   QVERIFY(time.getSec()==QTime::currentTime().second());
   QVERIFY(time.getMin()==QTime::currentTime().minute());
   QVERIFY(time.getHou()==QTime::currentTime().hour());

}
