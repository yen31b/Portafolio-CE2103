#ifndef TIMETEST_H
#define TIMETEST_H

#include "QtTest"
#include "Time.h"

class TimeTest: public QObject{
        Q_OBJECT

private:
    Time time;

private slots:
    void timeConstructorTest();
    void setGetTimeTest();
    void controlFormat();
    void setWrongTime();



};

#endif // TIMETEST_H
