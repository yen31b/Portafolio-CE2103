//
// Created by Fra on 22/08/2016.
//

#include <QCheckBox>
#include "TimerDisplay.h"

TimerDisplay::TimerDisplay(QTimeEdit* editor,Counter* counter, QWidget* parent):QLCDNumber(parent){
    setGeometry(20,240,421,141);

    this->editor=editor;
    this->setDigitCount(9);
    MyCounter=counter;
    attach();

    updateEditor();

   allowTimeout=false;

    player=new QMediaPlayer(this);
    QString path = "fra\Fallen.mp3";
    QMediaContent a(path);
    player->setMedia(a);

    sound.setParent(parent);
    QFont fontSound=sound.font();
    fontSound.setPointSize(10);
    sound.setText("Sound on/off");
    sound.setGeometry(450,350,150,31);

    connect(&sound,SIGNAL(clicked()),this,SLOT(SoundOnOff()));
    soundOn=true;

}


void TimerDisplay::attach(){
    MyCounter->subscribe(this);
}

void TimerDisplay::detach(){
    MyCounter->unsubscribe(this);
}


void TimerDisplay::fromStart(){
//controlla se non è in corso un conto alla rovescia e se non è in corso il TimeOut
    if(!active && !allowTimeout){
        active=true;
        allowTimeout=true;
        if(!paused)
            updateEditor();

        paused=false;
    }
}

void TimerDisplay::updateEditor(){

    QTime tempo=editor->time();

    thisTime.setHou(tempo.hour());
    thisTime.setMin(tempo.minute());
    thisTime.setSec(tempo.second());

    QString form="hh:mm:ss";

    thisTime.setFormat(form);

    text=QString::fromStdString(thisTime.getSHM());
    display(text);



    editor->setTime(QTime(0,0,0));
}

void TimerDisplay::refresh(){
    if(active){
        if(thisTime.getSec()>0)
            thisTime.setSec(thisTime.getSec()-1);
        else
        if(thisTime.getMin()>0){
           thisTime.setMin(thisTime.getMin()-1);
           thisTime.setSec(59);
        }
        else
        if(thisTime.getHou()>0){
            thisTime.setHou(thisTime.getHou()-1);
            thisTime.setMin(59);
            thisTime.setSec(59);
        }

        text=QString::fromStdString(thisTime.getSHM());
        display(text);

        if(thisTime.getHou()==0 && thisTime.getMin()==0 && thisTime.getSec()==0)
            TimeOut();


    }
}

Time& TimerDisplay::getThisTime(){
    return thisTime;
}


void TimerDisplay::TimeOut(){
    active=false;
    if(allowTimeout){
        if(soundOn)
            player->play();

        ChangeColor();
        callTimeout();

    }
}


void TimerDisplay::fromStop(){
    if(active){
        active=false;
        paused=true;
        allowTimeout=false;
    }
}


void TimerDisplay::fromReset(){
    active=false;
    paused=false;
    allowTimeout=false;
    thisTime.setTime(0,0,0);
    editor->setTime(QTime(0,0,0));
    text=QString::fromStdString(thisTime.getSHM());
    display(text);
    hideTimeout();
    player->stop();


    colore.setColor(QPalette::Active,QPalette::WindowText,QColor(0,0,0));
    this->setPalette(colore);
}


void TimerDisplay::ChangeColor(){
    /*
    if(QTime::currentTime().second()%2)
        colore.setColor(QPalette::Active,QPalette::WindowText,QColor(255,0,0));
    else
        colore.setColor(QPalette::Active,QPalette::WindowText,QColor(0,0,0));
    this->setPalette(colore);
    */
    colore.setColor(QPalette::Active,QPalette::WindowText,QColor(255,0,0));
    this->setPalette(colore);
}

void TimerDisplay::SoundOnOff() {
    if(soundOn)
        soundOn=false;
    else
        soundOn=true;

}

bool TimerDisplay::isTimeOut(){
    return allowTimeout;
}
