//
// Created by Fra on 22/08/2016.
//

#ifndef TIMERSCANDIFFIO_TIMERDISPLAY_H
#define TIMERSCANDIFFIO_TIMERDISPLAY_H


#include <QtMultimedia/qmediaplayer.h>
#include "QTimer"
#include "QLCDNumber"
#include "QTimeEdit"
#include "QObject"
#include "QCheckBox"
#include "QMediaPlayer"
#include "QUrl"
#include "observer.h"
#include "Time.h"
#include "Counter.h"




class TimerDisplay : public QLCDNumber,public Observer
{
Q_OBJECT

public:

    TimerDisplay(QTimeEdit* editor,Counter* counter,QWidget* parent=nullptr);
    //virtual ~TimerDisplay(); Il rilascio delle risorse è gestito dalla classe Base

    void refresh()override;
    void attach();
    void detach();

    Time& getThisTime();

    void updateEditor();
    bool isTimeOut();
    QTimeEdit* getEDitor(){
        return editor;
    }


private:

    bool active,paused,allowTimeout;
    bool soundOn;
    QTimeEdit* editor;

    QString text;
    QPalette colore;
    QCheckBox sound;

    QMediaPlayer *player;

    Counter* MyCounter;
    Time thisTime;






    void TimeOut();

signals:
    void callTimeout();
    void hideTimeout();

public slots:
    void fromStart();
    void fromStop();
    void fromReset();

private slots:
    void ChangeColor();
    void SoundOnOff();


};


#endif //TIMERSCANDIFFIO_TIMERDISPLAY_H
