#include "QApplication"
#include "QPushButton"
#include "QWidget"
#include "QLabel"
#include "QTimeEdit"
#include "QDateTime"

#include "TimerDisplay.h"
#include "MyClock.h"

#include "QObject"
#include "MyTimer.h"
#include "Counter.h"


int main(int argc, char *argv[]){

    QApplication app(argc, argv);

    QWidget* MyWidget= new MyTimer;
    MyWidget->setGeometry(500,200,617,416); //crea la schermata per il Widget


    Counter contatore;



    QPushButton start("Start",MyWidget);
    start.setGeometry(20,130,121,51);
    QFont font=start.font();
    font.setPointSize(15);

    QColor green(0,170,0);      //creo il colore verde
    QPalette color;
    color.setColor(QPalette::Active,QPalette::ButtonText,green);
    start.setPalette(color);  //ora il testo del bottone start é verde


    QPushButton stop("Stop",MyWidget);
    stop.setGeometry(320,130,121,51);

    QColor red(255,0,0);  //creo il colore rosso
    color.setColor(QPalette::Active,QPalette::ButtonText,red);
    stop.setPalette(color); //ora il testo del bottone stop é rosso

    QTimeEdit editor(MyWidget);
    editor.setGeometry(140,130,181,51);

    QFont edit_font=editor.font();
    edit_font.setPointSize(15);		   //Modifica grandezza Font orario
    editor.setAlignment(Qt::AlignHCenter); //allinea centralmente l'orario dell'editor

    QLabel timeout("TIME OUT!!",MyWidget);
    timeout.setGeometry(145,210,161,51);
    timeout.setAlignment(Qt::AlignCenter); //allinea centralmente la scritta
    color.setColor(QPalette::Active,QPalette::WindowText,red);
    timeout.setPalette(color);
    timeout.setVisible(false);  //inizialmente la scritta "TIME OUT" non è visibile

    QPushButton reset("Reset",MyWidget);
    reset.setGeometry(140,180,181,41);

    QColor heavenly(0,170,255);
    color.setColor(QPalette::Active,QPalette::ButtonText,heavenly);
    reset.setPalette(color);


    MyClock current_time(&contatore,MyWidget);


    TimerDisplay timer(&editor,&contatore,MyWidget);
    timer.setGeometry(20,260,421,141);



    //CONNESSIONI

    TimerDisplay::connect(&timer, SIGNAL(callTimeout()),&timeout,SLOT(show()));
    TimerDisplay::connect(&timer, SIGNAL(hideTimeout()),&timeout,SLOT(hide()));

    QPushButton::connect(&start,SIGNAL(clicked()),&timer,SLOT(fromStart()));
    QPushButton::connect(&stop,SIGNAL(clicked()),&timer,SLOT(fromStop()));
    QPushButton::connect(&reset,SIGNAL(clicked()),&timer,SLOT(fromReset()));


    app.setActiveWindow(MyWidget);
    MyWidget->show();


    return app.exec();
}
