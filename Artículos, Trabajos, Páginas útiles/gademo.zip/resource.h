//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gademo.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_FORMVIEW                    101
#define IDD_PARAMETERS                  101
#define IDD_OPERATORS                   102
#define IDR_MAINFRAME                   128
#define IDR_GADEMOTYPE                  129
#define GA_PROG_ICON                    130
#define IDC_APPLY                       1002
#define IDC_REVERT                      1003
#define IDC_PMUT                        1004
#define IDC_PCROSS                      1005
#define IDC_NGEN                        1006
#define IDC_POPSIZE                     1007
#define IDC_CLOSE                       1008
#define IDC_NPOP                        1009
#define IDC_OP_CLOSE                    1009
#define IDC_OP_REVERT                   1012
#define IDC_OP_APPLY                    1013
#define IDC_CROSS_UNIFORM               1014
#define IDC_CROSS_ONEPT                 1015
#define IDC_CROSS_TWOPT                 1016
#define IDC_CROSS_AVERAGE               1017
#define IDC_CROSS_BLX                   1018
#define IDC_MUT_UNIFORM                 1019
#define IDC_MUT_BOUNDARY                1020
#define IDC_MUT_GAUSSIAN                1021
#define IDC_MUT_FLIP                    1022
#define GA_MALG_SIMPLE                  32773
#define GA_MALG_SS                      32774
#define GA_MALG_CROWDING                32775
#define GA_MFUNC_RIPPLES                32776
#define GA_MFUNC_LOAF                   32777
#define GA_MFUNC_FOXHOLES               32778
#define GA_CNTRL_REWIND                 32783
#define GA_CNTRL_STOP                   32784
#define GA_CNTRL_STEP                   32785
#define GA_CNTRL_EVOLVE                 32786
#define GA_CNTRL_SOME                   32788
#define GA_MALG_INCREMENTAL             32790
#define GA_MALG_DEME                    32791
#define GA_MFUNC_SCHWEFEL               32792
#define GA_PARAMETERS                   32793
#define GA_MREP_REAL                    32794
#define GA_MREP_BIN                     32795
#define GA_MALG_SS_SHARING              32796
#define GA_MFUNC_RIPPLE_SHIFT           32797
#define GA_VIEW_GRID                    32798
#define GA_MREP_BIN8                    32799
#define GA_MREP_OPERATORS               32800

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32801
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
